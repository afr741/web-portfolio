<?php include "../assets"; ?>
 <html lang="en">
 <head>
 <meta charset="UTF-8">
 <title> Anush's Portfolio</title>
 <meta name = "viewpoint" content = "width=device-width, user-scalable=no,
 initial-scale = 1.0, maximum-scale = 1.0, minimum-scale = 1.0">
 

 <!--Font Awesome-->

<link rel = "stylesheet href = "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<!--styles-->
 <link rel ="stylesheet" href="assets/css/main.css">
 <div class = "header">
 	
 <div>
 </head>
<body> 

	<div class="header-background ">
	<header class = "header header--sticky">
		
		<div class = "container header__container">

			

			<a href="index.html"><img id="header-logo" src="assets/images/logo.png" alt="logo" ></a>
			<a href = "index.html" class="button header__button" id = "header-buttons"> About</a><br>
			<a href = "index.html#port-title" class="button header__button" id = "header-buttons"> My projects</a><br>
			<a href = "https://drive.google.com/file/d/15lDKvoQtnumE4cjRbjmDP0JtaTeI-j90/view?usp=sharing" class="button  header__button" id = "header-buttons">Resume</a><br>

			<a href = "index.html#other-works" class="button  header__button" id = "header-buttons"> Other works</a><br>
			<a href = "contact.html" class="button  header__button" id = "header-buttons"> Contact Me </a><br>


		</div>
	</header>


		<div class="contact-container ">
  <form name "contactform"  method ="POST">

    <label for="fname">First Name</label>
    <input type="text" id="fname" name="first_name" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="last_name" placeholder="Your last name..">

    <label for="email">Email Address</label>
    <input type="text" id="country" name="email" placeholder="Your email..">


    <label for="subject">Subject</label>
    <textarea id="subject" name="comments" placeholder="Dont forget to include your contact info.." style="height:200px"></textarea>

    <input type="submit" value="Submit">

  </form>
</div>
		
 
	
	<footer class = "container">
		<ul class = "footer-list">
			<li class = "footer-list__item"> ©Anushervon Rakhmatov 2018. All Rights Reserved></li>
		
			<ul>
	</footer>
	<?php
if(isset($_POST['email'])) {
 
    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_to = "afr741@mun.ca";
    $email_subject = "web portfolio email";
 
    function died($error) {
        // your error code can go here
        echo "We are very sorry, but there were error(s) found with the form you submitted. ";
        echo "These errors appear below.<br /><br />";
        echo $error."<br /><br />";
        echo "Please go back and fix these errors.<br /><br />";
        die();
    }
 
 
    // validation expected data exists
    if(!isset($_POST['first_name']) ||
        !isset($_POST['last_name']) ||
        !isset($_POST['email']) ||
        !isset($_POST['comments'])) {
        died('We are sorry, but there appears to be a problem with the form you submitted.');       
    }
 
     
 
    $first_name = $_POST['first_name']; // required
    $last_name = $_POST['last_name']; // required
    $email_from = $_POST['email']; // required
    $comments = $_POST['comments']; // required
 
    $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
 
    $string_exp = "/^[A-Za-z .'-]+$/";
 
  if(!preg_match($string_exp,$first_name)) {
    $error_message .= 'The First Name you entered does not appear to be valid.<br />';
  }
 
  if(!preg_match($string_exp,$last_name)) {
    $error_message .= 'The Last Name you entered does not appear to be valid.<br />';
  }
 
  if(strlen($comments) < 2) {
    $error_message .= 'The Comments you entered do not appear to be valid.<br />';
  }
 
  if(strlen($error_message) > 0) {
    died($error_message);
  }
 
    $email_message = "Form details below.\n\n";
 
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
 
     
 
    $email_message .= "First Name: ".clean_string($first_name)."\n";
    $email_message .= "Last Name: ".clean_string($last_name)."\n";
    $email_message .= "Email: ".clean_string($email_from)."\n";
    $email_message .= "Comments: ".clean_string($comments)."\n";
 
// create email headers
$headers = 'From: '.$email_from."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);  
?>
 
<!-- include your own success html here -->
 
Thank you for contacting us. We will be in touch with you very soon.
 
<?php
 
}
?>
 	
</body>
</html>